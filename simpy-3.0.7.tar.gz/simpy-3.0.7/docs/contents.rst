=======================
Documentation for SimPy
=======================

Contents:

.. toctree::
   :maxdepth: 2

   SimPy home <index>
   simpy_intro/index
   topical_guides/index
   examples/index
   api_reference/index
   about/index


Indices and tables
==================

* :ref:`genindex`
* :ref:`search`
