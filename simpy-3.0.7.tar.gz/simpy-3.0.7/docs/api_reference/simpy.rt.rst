=====================================
``simpy.rt`` --- Real-time simulation
=====================================

.. automodule:: simpy.rt
   :inherited-members:
