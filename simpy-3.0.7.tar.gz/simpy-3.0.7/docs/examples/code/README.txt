The ``*.out`` files contain the output for the corresponding ``*.py`` files.

Since Python 2 produces different random numbers (given the same seed) than
Python 3, there are extra ``*.out2`` files for examples using random numbers.
